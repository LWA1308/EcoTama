// ==================== STATE ====================
let state = {
  points: 0,
  hp: 70,
  level: 1,
  streak: 0,
  quizIndex: 0,
  quizCorrect: 0,
  quizAnswered: false,
  feedUsed: [],
  gameCorrect: 0,
  gameTotal: 0,
  dragItem: null,
  petName: 'EcoTama',
  petPath: 0,       // which evolution path
  habitatTheme: 0,  // which habitat
  accentColor: '#4caf78' // theme accent
};

// Each path defines emojis per stage (egg → legend)
const PET_PATHS = [
  { name:'Tartaruga', icon:'🐢', stages:['🥚','🌱','🐢','🦋','🦚','🌳','🐉'] },
  { name:'Coelho',    icon:'🐇', stages:['🥚','🌱','🐇','🦊','🦁','🌳','🦅'] },
  { name:'Panda',     icon:'🐼', stages:['🥚','🌱','🐼','🐨','🦘','🌳','🐲'] },
  { name:'Sapo',      icon:'🐸', stages:['🥚','🌱','🐸','🦎','🐊','🌳','🔱'] },
  { name:'Coruja',    icon:'🦉', stages:['🥚','🌱','🦉','🦜','🦚','🌳','🌟'] },
  { name:'Golfinho',  icon:'🐬', stages:['🥚','🌱','🐬','🐳','🦈','🌳','🌊'] },
  { name:'Raposa',    icon:'🦊', stages:['🥚','🌱','🦊','🐺','🦁','🌳','⚡'] },
  { name:'Borboleta', icon:'🦋', stages:['🥚','🌱','🐛','🦋','🦄','🌳','✨'] },
];

const HABITATS = [
  { name:'Floresta',  sky:'linear-gradient(180deg,#0d2a40,#1a4a6a)', ground:'linear-gradient(180deg,#1a4a2e,#0f2a1a)', label:'🌲' },
  { name:'Praia',     sky:'linear-gradient(180deg,#1a4a7a,#2980b9)', ground:'linear-gradient(180deg,#c2b280,#a0936a)', label:'🏖️' },
  { name:'Savana',    sky:'linear-gradient(180deg,#8b4513,#d2691e)', ground:'linear-gradient(180deg,#8b6914,#6b4f10)', label:'🌅' },
  { name:'Ártico',    sky:'linear-gradient(180deg,#1a3a5a,#2c5f8a)', ground:'linear-gradient(180deg,#d0e8f0,#a8d4e8)', label:'🏔️' },
  { name:'Vulcão',    sky:'linear-gradient(180deg,#2a0a0a,#4a1010)', ground:'linear-gradient(180deg,#3a1a0a,#1a0a0a)', label:'🌋' },
  { name:'Fundo Mar', sky:'linear-gradient(180deg,#001a2e,#003366)', ground:'linear-gradient(180deg,#003355,#001a2e)', label:'🐠' },
];

const ACCENT_COLORS = [
  '#4caf78','#3498db','#f9e04b','#e74c3c','#9b59b6',
  '#f5a623','#1abc9c','#e91e8c','#00bcd4','#ff5722',
];

const PET_STAGE_MINS = [0, 50, 150, 300, 500, 800, 1000];

function getPetStage() {
  const path = PET_PATHS[state.petPath];
  let stageIdx = 0;
  for (let i = 0; i < PET_STAGE_MINS.length; i++) {
    if (state.points >= PET_STAGE_MINS[i]) stageIdx = i;
    else break;
  }
  return { emoji: path.stages[stageIdx], name: path.name };
}

// ==================== FEED ITEMS ====================
const FEED_ITEMS = [
  { id:'f1', icon:'🚿', name:'BANHO CURTO', pts:15, hp:5 },
  { id:'f2', icon:'🛍️', name:'SACOLA REUTILIZÁVEL', pts:10, hp:3 },
  { id:'f3', icon:'🌱', name:'PLANTOU ALGO', pts:20, hp:8 },
  { id:'f4', icon:'🚲', name:'FOI DE BIKE', pts:25, hp:10 },
  { id:'f5', icon:'♻️', name:'RECICLOU LIXO', pts:15, hp:5 },
  { id:'f6', icon:'💡', name:'ECONOMIZOU ENERGIA', pts:12, hp:4 },
  { id:'f7', icon:'🥗', name:'REFEIÇÃO VEGANA', pts:18, hp:6 },
  { id:'f8', icon:'🚌', name:'TRANSPORTE PÚBLICO', pts:20, hp:7 },
  { id:'f9', icon:'🛁', name:'COMPOSTAGEM', pts:22, hp:9 },
];

function renderFeed() {
  const grid = document.getElementById('feedGrid');
  grid.innerHTML = '';
  FEED_ITEMS.forEach(item => {
    const used = state.feedUsed.includes(item.id);
    grid.innerHTML += `
      <div class="feed-item ${used?'used':''}" onclick="doFeed('${item.id}')">
        <span class="icon">${item.icon}</span>
        <div class="name">${item.name}</div>
        <div class="pts">+${item.pts}pts</div>
      </div>`;
  });
}

function doFeed(id) {
  if (state.feedUsed.includes(id)) return;
  const item = FEED_ITEMS.find(f => f.id === id);
  state.feedUsed.push(id);
  addPoints(item.pts);
  addHP(item.hp);
  state.streak++;
  updateUI();
  renderFeed();
  showBubble(`+${item.pts} pontos! ${item.icon}`);
  petHappy();
  showPtsPopup(`+${item.pts}✨`);
}

// ==================== QUIZ ====================
const QUESTIONS = [
  // -- PERGUNTAS ORIGINAIS --
  {
    q: 'Qual é o principal gás responsável pelo aquecimento global?',
    opts: ['Oxigênio (O₂)', 'Dióxido de Carbono (CO₂)', 'Nitrogênio (N₂)', 'Hidrogênio (H₂)'],
    correct: 1,
    explain: 'O CO₂ é o principal gás do efeito estufa gerado por atividades humanas, como queima de combustíveis fósseis.'
  },
  {
    q: 'Quantos litros de água um vazamento de torneira pode desperdiçar por dia?',
    opts: ['Até 5 litros', 'Até 20 litros', 'Até 60 litros', 'Até 200 litros'],
    correct: 3,
    explain: 'Uma torneira gotejando pode desperdiçar até 200 litros de água por dia! Pequenos vazamentos têm grande impacto.'
  },
  {
    q: 'Qual lixeira deve receber embalagens de papel limpo?',
    opts: ['🔴 Vermelha (plástico)', '🔵 Azul (papel)', '🟡 Amarela (metal)', '🟢 Verde (vidro)'],
    correct: 1,
    explain: 'Papéis, jornais, revistas e caixas limpas vão na lixeira azul na coleta seletiva brasileira.'
  },
  {
    q: 'O que é "pegada de carbono"?',
    opts: [
      'Uma pegada de dinossauro fossilizado',
      'A quantidade de CO₂ emitida pelas nossas atividades',
      'Um tipo de carvão mineral',
      'O tamanho do seu pé em carbono'
    ],
    correct: 1,
    explain: 'Pegada de carbono mede a quantidade de CO₂ e gases equivalentes que nossas ações liberam na atmosfera.'
  },
  {
    q: 'Qual prática NÃO ajuda a economizar energia elétrica?',
    opts: [
      'Usar lâmpadas LED',
      'Deixar aparelhos em standby na tomada',
      'Aproveitar luz natural',
      'Lavar roupas com água fria'
    ],
    correct: 1,
    explain: 'Aparelhos em standby continuam consumindo energia. Desconectar da tomada pode economizar até 10% na conta!'
  },
  {
    q: 'Quanto tempo leva para uma garrafa PET se degradar na natureza?',
    opts: ['10 anos', '50 anos', '100 anos', 'Mais de 400 anos'],
    correct: 3,
    explain: 'Uma garrafa PET pode levar mais de 400 anos para se decompor! Por isso a reciclagem é tão importante.'
  },
  {
    q: 'O que é compostagem?',
    opts: [
      'Um tipo de reciclagem de plástico',
      'Transformar resíduos orgânicos em adubo natural',
      'Queimar lixo para gerar energia',
      'Separar metais para reciclagem'
    ],
    correct: 1,
    explain: 'Compostagem transforma restos de alimentos e folhas em adubo rico em nutrientes para o solo!'
  },
  {
    q: 'Qual é a fonte de energia mais limpa e renovável?',
    opts: ['Carvão mineral', 'Gás natural', 'Energia solar', 'Energia nuclear'],
    correct: 2,
    explain: 'A energia solar não emite gases poluentes e usa uma fonte inesgotável: o Sol! Também está ficando cada vez mais barata.'
  },
  {
    q: 'O que significa o símbolo de reciclagem com 3 setas?',
    opts: [
      'O produto veio de 3 países',
      'É biodegradável em 3 dias',
      'Pode ser reciclado',
      'Contém 3 materiais diferentes'
    ],
    correct: 2,
    explain: 'O símbolo das 3 setas (♻️) indica que o material pode ser reciclado. Cada cor pode indicar o tipo de material.'
  },
  {
    q: 'Qual destas ações tem MAIOR impacto na redução da pegada de carbono?',
    opts: [
      'Desligar o carregador da tomada',
      'Reduzir o consumo de carne vermelha',
      'Usar sacola reutilizável',
      'Imprimir menos papel'
    ],
    correct: 1,
    explain: 'A produção de carne bovina é responsável por até 14,5% das emissões globais de gases do efeito estufa!'
  },
  {
    q: 'Como podemos economizar água em casa?',
    opts: [
      'Deixando a torneira aberta enquanto escovamos os dentes',
      'Tomando banhos rápidos e consertando vazamentos',
      'Lavando o carro com mangueira todo dia',
      'Tomar banhos demorados e longos'
    ],
    correct: 1,
    explain: 'Economizar água nos banhos e consertar vazamentos economiza muita água!'
  },
  {
    q: 'Qual lixeira deve receber plástico?',
    opts: ['🔴 Vermelha (plástico)', '🔵 Azul (papel)', '🟡 Amarela (metal)', '🟢 Verde (vidro)'],
    correct: 0,
    explain: 'Garrafas PET, canudos de Plástico, embalagens e sacolas vão na lixeira vermelha na coleta seletiva brasileira.'
  },

  // -- NOVAS PERGUNTAS INFANTIS --
  {
    q: '🌳 As árvores são muito importantes! O que elas fazem pelo ar que respiramos?',
    opts: [
      'Nada, são só bonitas',
      'Elas limpam o ar e produzem oxigênio',
      'Elas produzem chuva sozinhas',
      'Elas aquentam o planeta'
    ],
    correct: 1,
    explain: 'As árvores absorvem CO₂ e liberam oxigênio para o ar! Por isso é tão importante plantar e proteger as florestas. 🌿'
  },
  {
    q: '🐋 O que os animais marinhos sofrem por causa do lixo plástico no mar?',
    opts: [
      'Eles ficam mais fortes',
      'Eles ganham novas casinhas',
      'Eles podem engolir o plástico e ficam doentes',
      'Eles adoram brincar com o plástico'
    ],
    correct: 2,
    explain: 'Animais como tartarugas, baleias e golfinhos podem engolir plástico por acidente. Por isso não jogue lixo na praia ou no rio! 🌊'
  },
  {
    q: '🌈 Qual dessas atitudes é mais sustentável no dia a dia?',
    opts: [
      'Usar copo descartável toda vez',
      'Jogar pilha no lixo comum',
      'Levar garrafinha de água reutilizável',
      'Deixar as luzes acesas sempre'
    ],
    correct: 2,
    explain: 'Usar garrafinha reutilizável evita o uso de dezenas de garrafinhas plásticas por mês. Pequenas mudanças fazem grande diferença! 💧'
  },
  {
    q: '🐝 Por que as abelhas são tão importantes para o planeta?',
    opts: [
      'Porque produzem mel para vender',
      'Porque elas polinizam as plantas e flores',
      'Porque elas asustam as pessoas',
      'Porque comem mosquitos'
    ],
    correct: 1,
    explain: 'As abelhas polinizam as flores, ajudando as plantas a produzirem frutos e sementes. Sem elas, muitos alimentos desapareceriam! 🌸'
  },
  {
    q: '🌧️ O que é o ciclo da água?',
    opts: [
      'Quando a água dá voltas na banheira',
      'Quando chove só no inverno',
      'Quando a água evapora, forma nuvens e volta como chuva',
      'Quando bebemos água todos os dias'
    ],
    correct: 2,
    explain: 'A água evapora do mar e dos rios, sobe ao céu e forma nuvens, depois volta como chuva. Esse ciclo nunca para! ☁️'
  },
  {
    q: '🌻 O que acontece quando desmatamos as florestas?',
    opts: [
      'Aparecem mais animais',
      'O ar fica mais limpo',
      'Muitos animais perdem seus lares e o planeta esquenta mais',
      'Surgem mais rios'
    ],
    correct: 2,
    explain: 'Quando cortamos árvores, os animais perdem seu lar e há menos plantas para limpar o ar. A floresta é nossa amiga! 🦜'
  },
  {
    q: '♻️ Qual destes objetos NÃO pode ser reciclado normalmente?',
    opts: [
      'Garrafa de vidro',
      'Lata de alumínio',
      'Esponja de cozinha usada',
      'Caixa de papelão'
    ],
    correct: 2,
    explain: 'Esponjas de cozinha misturam vários materiais e ficam sujas. Vidro, alumínio e papelão limpos são fáceis de reciclar! ♻️'
  },
  {
    q: '🦁 O que significa um animal estar "em extinção"?',
    opts: [
      'Que ele é muito famoso',
      'Que ele tem pouquíssimos indivíduos e pode desaparecer para sempre',
      'Que ele é muito grande',
      'Que ele mora longe'
    ],
    correct: 1,
    explain: 'Quando uma espécie está em extinção, restam muito poucos animais desse tipo. Se não cuidarmos, eles podem desaparecer para sempre! 🐾'
  },
  {
    q: '🌡️ Por que a temperatura da Terra está aumentando?',
    opts: [
      'Porque o Sol está ficando mais perto',
      'Por causa da poluição que jogamos no ar',
      'Porque tem mais pessoas no mundo',
      'Porque os oceanos estão crescendo'
    ],
    correct: 1,
    explain: 'A poluição dos carros, fábricas e desmatamento libera gases que aquecem a Terra, como se fosse uma estufa gigante! 🏭'
  },
  {
    q: '🌱 O que é biodiversidade?',
    opts: [
      'O nome de um jogo de videogame',
      'A quantidade de dinheiro no campo',
      'A variedade de plantas, animais e seres vivos no planeta',
      'Uma vacina para animais'
    ],
    correct: 2,
    explain: 'Biodiversidade é toda a variedade de seres vivos! Quanto mais espécies, mais saudável é o planeta. Cada animal importa! 🦋'
  },
  {
    q: '💧 Por que devemos economizar água?',
    opts: [
      'Porque a conta de água fica cara',
      'Porque água doce é rara e todos os seres vivos precisam dela',
      'Porque a chuva não existe mais',
      'Porque o mar vai secar'
    ],
    correct: 1,
    explain: 'Só 3% da água do planeta é doce e potável! Economizar água garante que todos — pessoas, animais e plantas — tenham o suficiente. 🌍'
  },
  {
    q: '🚗 Qual meio de transporte polui menos o ar?',
    opts: [
      'Carro a gasolina',
      'Moto',
      'Bicicleta',
      'Caminhão'
    ],
    correct: 2,
    explain: 'A bicicleta não queima combustível e não solta fumaça! Pedalar é ótimo para o planeta e para a saúde. 🚴'
  },
  {
    q: '🌍 O que acontece quando jogamos lixo no chão na rua?',
    opts: [
      'O lixo desaparece rápido',
      'Ele pode entupir bueiros e poluir rios e oceanos',
      'Fica bonito para decorar a rua',
      'Vira adubo na hora'
    ],
    correct: 1,
    explain: 'O lixo na rua vai parar nos bueiros, depois nos rios e no mar. Por isso cada lixinho importa — use sempre a lixeira! 🗑️'
  },
  {
    q: '🌞 O que as plantas precisam para crescer?',
    opts: [
      'Apenas água',
      'Apenas luz do sol',
      'Água, luz do sol e nutrientes da terra',
      'Sorvete e música'
    ],
    correct: 2,
    explain: 'As plantas precisam de água, sol e nutrientes do solo para crescerem e nos dar oxigênio, sombra e alimento! 🌿'
  },
  {
    q: '🐸 Por que os sapos e rãs são indicadores da saúde do ambiente?',
    opts: [
      'Porque cantam bonito',
      'Porque a pele deles absorve poluentes e eles adoecem quando o ambiente está poluído',
      'Porque comem muito',
      'Porque são muito coloridos'
    ],
    correct: 1,
    explain: 'A pele dos sapos absorve tudo do ambiente. Se há poluição na água ou no ar, eles adoecem primeiro! São como alarmes da natureza. 🌱'
  },
];


let quizQueue = [];
let currentQ = null;

function openQuiz() {
  // Pick 5 random questions
  quizQueue = [...QUESTIONS].sort(() => Math.random() - 0.5).slice(0, 5);
  state.quizIndex = 0;
  state.quizCorrect = 0;
  renderQuestion();
  openModal('quizModal');
}

function renderQuestion() {
  currentQ = quizQueue[state.quizIndex];
  const total = quizQueue.length;
  document.getElementById('quizProgress').textContent = `PERGUNTA ${state.quizIndex + 1}/${total}`;
  document.getElementById('nextQuizBtn').style.display = 'none';
  state.quizAnswered = false;

  let optsHTML = currentQ.opts.map((o, i) =>
    `<button class="quiz-opt" onclick="answerQuiz(${i})">${o}</button>`
  ).join('');

  document.getElementById('quizContent').innerHTML = `
    <div class="quiz-question">
      <p>${currentQ.q}</p>
    </div>
    <div class="quiz-options">${optsHTML}</div>
    <div class="quiz-feedback" id="quizFeedback"></div>
  `;
}

function answerQuiz(idx) {
  if (state.quizAnswered) return;
  state.quizAnswered = true;
  const opts = document.querySelectorAll('.quiz-opt');
  const feedback = document.getElementById('quizFeedback');
  const isCorrect = idx === currentQ.correct;

  opts.forEach((o, i) => {
    o.classList.add('disabled');
    if (i === currentQ.correct) o.classList.add('correct');
    else if (i === idx && !isCorrect) o.classList.add('wrong');
  });

  if (isCorrect) {
    state.quizCorrect++;
    addPoints(20);
    addHP(5);
    feedback.className = 'quiz-feedback show ok';
    feedback.textContent = '✅ Correto! ' + currentQ.explain;
    showPtsPopup('+20✨');
    petHappy();
  } else {
    addHP(-5);
    feedback.className = 'quiz-feedback show fail';
    feedback.textContent = '❌ ' + currentQ.explain;
    petSad();
  }

  updateUI();

  const isLast = state.quizIndex === quizQueue.length - 1;
  const nextBtn = document.getElementById('nextQuizBtn');
  nextBtn.style.display = 'block';
  nextBtn.textContent = isLast ? 'VER RESULTADO →' : 'PRÓXIMA →';
}

function nextQuestion() {
  state.quizIndex++;
  if (state.quizIndex >= quizQueue.length) {
    showQuizResult();
    return;
  }
  renderQuestion();
}

function showQuizResult() {
  const pct = Math.round(state.quizCorrect / quizQueue.length * 100);
  let emoji = pct >= 80 ? '🏆' : pct >= 60 ? '😊' : '📚';
  let msg = pct >= 80 ? 'Incrível! Você é um(a) expert em sustentabilidade!'
    : pct >= 60 ? 'Bom trabalho! Continue aprendendo!'
    : 'Continue estudando! O planeta conta com você!';

  const bonus = state.quizCorrect * 5;
  if (bonus > 0) { addPoints(bonus); updateUI(); }

  document.getElementById('quizContent').innerHTML = `
    <div class="game-result show">
      <div class="big-icon">${emoji}</div>
      <h3>${state.quizCorrect}/${quizQueue.length} CORRETAS</h3>
      <p style="margin:8px 0">${msg}</p>
      <p style="color:var(--yellow);font-weight:800;font-size:14px">+${bonus} pontos bônus!</p>
    </div>`;
  document.getElementById('nextQuizBtn').style.display = 'none';
  document.getElementById('quizProgress').textContent = 'RESULTADO FINAL';
  if (pct >= 80) celebrate();
}

// ==================== MINI GAME ====================
const TRASH_CATEGORIES = [
  { id:'recycle', name:'RECICLÁVEL', icon:'♻️', color:'#3498db', items:[] },
  { id:'organic', name:'ORGÂNICO', icon:'🌿', color:'#4caf78', items:[] },
  { id:'hazard', name:'PERIGOSO', icon:'☠️', color:'#e74c3c', items:[] },
  { id:'general', name:'GERAL', icon:'🗑️', color:'#95a5a6', items:[] },
];

const TRASH_ITEMS = [
  { emoji:'🍌', name:'Casca de banana', cat:'organic' },
  { emoji:'📰', name:'Jornal', cat:'recycle' },
  { emoji:'🔋', name:'Pilha', cat:'hazard' },
  { emoji:'🥤', name:'Copo plástico', cat:'recycle' },
  { emoji:'🍃', name:'Folhas', cat:'organic' },
  { emoji:'💊', name:'Remédio vencido', cat:'hazard' },
  { emoji:'🥛', name:'Caixa de leite', cat:'recycle' },
  { emoji:'🍎', name:'Resto de fruta', cat:'organic' },
  { emoji:'🔌', name:'Cabo velho', cat:'hazard' },
  { emoji:'📦', name:'Caixa papelão', cat:'recycle' },
  { emoji:'🥕', name:'Legume velho', cat:'organic' },
  { emoji:'🪫', name:'Bateria', cat:'hazard' },
  { emoji:'🍶', name:'Garrafa vidro', cat:'recycle' },
  { emoji:'☕', name:'Borra de café', cat:'organic' },
  { emoji:'🧪', name:'Tinta velha', cat:'hazard' },
];

let gameItems = [];
let gameAnswers = {};
let gameTotal = 0;

function openGame() {
  // Pick 8 random items
  gameItems = [...TRASH_ITEMS].sort(() => Math.random() - 0.5).slice(0, 8);
  gameAnswers = {};
  gameTotal = gameItems.length;
  renderGame();
  openModal('gameModal');
}

function renderGame() {
  const container = document.getElementById('gameContent');

  const zones = TRASH_CATEGORIES.map(c => `
    <div class="trash-zone" id="zone_${c.id}"
      style="border-color:${c.id==='recycle'?'rgba(52,152,219,0.3)':c.id==='organic'?'rgba(76,175,120,0.3)':c.id==='hazard'?'rgba(231,76,60,0.3)':'rgba(149,165,166,0.3)'};background:${c.id==='recycle'?'rgba(52,152,219,0.05)':c.id==='organic'?'rgba(76,175,120,0.05)':c.id==='hazard'?'rgba(231,76,60,0.05)':'rgba(149,165,166,0.05)'}"
      ondragover="ev.preventDefault();this.classList.add('dragover')"
      ondragleave="this.classList.remove('dragover')"
      ondrop="dropItem('${c.id}',event)">
      <div class="zone-icon">${c.icon}</div>
      <div class="zone-name">${c.name}</div>
      <div id="zone_placed_${c.id}" style="display:flex;flex-wrap:wrap;gap:4px;justify-content:center;margin-top:4px"></div>
    </div>`).join('');

  const chips = gameItems.map(item => `
    <div class="drag-chip" id="chip_${item.name.replace(/\s/g,'_')}"
      draggable="true"
      ondragstart="startDrag('${item.name}','${item.cat}',event)"
      onclick="tapItem('${item.name}','${item.cat}')">
      ${item.emoji} ${item.name}
    </div>`).join('');

  container.innerHTML = `
    <div class="trash-zones">${zones}</div>
    <div class="draggable-items" id="chipArea">${chips}</div>
    <div class="game-result" id="gameResult"></div>
    <button class="action-btn btn-secondary" id="checkGameBtn" onclick="checkGame()">VERIFICAR ✓</button>
  `;
}

let dragData = null;

function startDrag(name, cat, ev) {
  dragData = { name, cat };
  ev.dataTransfer.effectAllowed = 'move';
}

function dropItem(zoneId, ev) {
  ev.preventDefault();
  document.querySelectorAll('.trash-zone').forEach(z => z.classList.remove('dragover'));
  if (!dragData) return;
  placeItem(dragData.name, dragData.cat, zoneId);
  dragData = null;
}

// Tap mode for mobile
let tapState = null;
function tapItem(name, cat) {
  if (tapState === null) {
    tapState = { name, cat };
    document.querySelectorAll('.drag-chip').forEach(c => {
      if (c.textContent.includes(name.split(' ')[0])) c.style.border = '2px solid var(--yellow)';
    });
    document.querySelectorAll('.trash-zone').forEach(z => {
      z.style.cursor = 'pointer';
      z.onclick = function() {
        const zoneId = this.id.replace('zone_','');
        placeItem(tapState.name, tapState.cat, zoneId);
        tapState = null;
        document.querySelectorAll('.trash-zone').forEach(z2 => z2.onclick = null);
      };
    });
  }
}

function placeItem(name, cat, zoneId) {
  const chipId = 'chip_' + name.replace(/\s/g,'_');
  const chip = document.getElementById(chipId);
  if (!chip || chip.classList.contains('placed')) return;

  gameAnswers[name] = zoneId;
  chip.classList.add('placed');
  chip.style.border = '';

  const item = gameItems.find(i => i.name === name);
  if (!item) return;
  const placedArea = document.getElementById('zone_placed_' + zoneId);
  if (placedArea) {
    placedArea.innerHTML += `<span style="font-size:16px" title="${name}">${item.emoji}</span>`;
  }

  // Auto check if all placed
  if (Object.keys(gameAnswers).length === gameTotal) {
    setTimeout(checkGame, 400);
  }
}

function checkGame() {
  let correct = 0;
  gameItems.forEach(item => {
    if (gameAnswers[item.name] === item.cat) correct++;
  });

  const pct = Math.round(correct / gameTotal * 100);
  const pts = correct * 10;
  addPoints(pts);
  addHP(Math.round(correct * 2));
  updateUI();

  const emoji = pct >= 80 ? '🏆' : pct >= 60 ? '🎉' : '📚';
  const msg = pct >= 80 ? 'Mestre da reciclagem!' : pct >= 60 ? 'Muito bem!' : 'Continue praticando!';

  document.getElementById('gameResult').className = 'game-result show';
  document.getElementById('gameResult').innerHTML = `
    <div class="big-icon">${emoji}</div>
    <h3>${correct}/${gameTotal} CORRETOS</h3>
    <p>${msg}</p>
    <p style="color:var(--yellow);font-weight:800;font-size:14px;margin-top:8px">+${pts} pontos!</p>
  `;
  document.getElementById('checkGameBtn').style.display = 'none';
  document.querySelector('#gameModal .modal-title').textContent = '🎮 Resultado!';

  if (pts > 0) showPtsPopup(`+${pts}✨`);
  if (pct >= 80) { celebrate(); petHappy(); }
}

// ==================== TOUCH DRAG SUPPORT ====================
function enableTouchDrag() {
  let activeDragEl = null;
  let activeDragData = null;
  let ghost = null;

  document.addEventListener('touchstart', function(e) {
    const chip = e.target.closest('.drag-chip');
    if (!chip || chip.classList.contains('placed')) return;
    e.preventDefault();
    activeDragEl = chip;
    // Extract name/cat from onclick attribute
    const onclickStr = chip.getAttribute('onclick') || '';
    const match = onclickStr.match(/tapItem\('([^']+)','([^']+)'\)/);
    if (match) activeDragData = { name: match[1], cat: match[2] };
    const touch = e.touches[0];
    ghost = chip.cloneNode(true);
    ghost.style.cssText = `position:fixed;opacity:0.85;pointer-events:none;z-index:9999;
      transform:scale(1.08);transition:none;left:${touch.clientX - chip.offsetWidth/2}px;
      top:${touch.clientY - chip.offsetHeight/2}px;width:${chip.offsetWidth}px;`;
    document.body.appendChild(ghost);
    chip.style.opacity = '0.3';
  }, { passive: false });

  document.addEventListener('touchmove', function(e) {
    if (!ghost) return;
    e.preventDefault();
    const touch = e.touches[0];
    ghost.style.left = (touch.clientX - ghost.offsetWidth/2) + 'px';
    ghost.style.top  = (touch.clientY - ghost.offsetHeight/2) + 'px';
    document.querySelectorAll('.trash-zone').forEach(z => z.classList.remove('dragover'));
    const el = document.elementFromPoint(touch.clientX, touch.clientY);
    const zone = el && el.closest('.trash-zone');
    if (zone) zone.classList.add('dragover');
  }, { passive: false });

  document.addEventListener('touchend', function(e) {
    if (!ghost || !activeDragEl) return;
    const touch = e.changedTouches[0];
    ghost.remove(); ghost = null;
    activeDragEl.style.opacity = '';
    const el = document.elementFromPoint(touch.clientX, touch.clientY);
    const zone = el && el.closest('.trash-zone');
    document.querySelectorAll('.trash-zone').forEach(z => z.classList.remove('dragover'));
    if (zone && activeDragData) {
      const zoneId = zone.id.replace('zone_','');
      placeItem(activeDragData.name, activeDragData.cat, zoneId);
    }
    activeDragEl = null;
    activeDragData = null;
  });
}
enableTouchDrag();
function addPoints(n) {
  state.points = Math.max(0, state.points + n);
  const newLevel = Math.floor(state.points / 100) + 1;
  if (newLevel > state.level) {
    state.level = newLevel;
    levelUp();
  }
}

function addHP(n) {
  state.hp = Math.max(0, Math.min(100, state.hp + n));
}

function updateUI() {
  document.getElementById('totalPts').textContent = state.points;
  document.getElementById('levelVal').textContent = state.level;
  document.getElementById('streakVal').textContent = state.streak + '🔥';

  const hp = state.hp;
  document.getElementById('hpText').textContent = `${hp}/100`;
  const bar = document.getElementById('hpBar');
  bar.style.width = hp + '%';
  if (hp > 60) bar.style.background = 'linear-gradient(90deg,#4caf78,#a8e6bf)';
  else if (hp > 30) bar.style.background = 'linear-gradient(90deg,#f5a623,#f9e04b)';
  else bar.style.background = 'linear-gradient(90deg,#e74c3c,#f39c12)';

  const stage = getPetStage();
  document.getElementById('pet').textContent = stage.emoji;

  // Pet name labels
  const name = state.petName || 'EcoTama';
  const nameEl = document.getElementById('petNameLabel');
  if (nameEl) nameEl.textContent = name;
  const headerName = document.getElementById('headerPetName');
  if (headerName) headerName.textContent = '✦ ' + name + ' ✦';

  // Apply habitat
  applyHabitat();
  // Apply accent color CSS var
  document.documentElement.style.setProperty('--green-light', state.accentColor);
}

function petHappy() {
  const pet = document.getElementById('pet');
  pet.classList.remove('happy','sad');
  void pet.offsetWidth;
  pet.classList.add('happy');
  setTimeout(() => pet.classList.remove('happy'), 1500);
}

function petSad() {
  const pet = document.getElementById('pet');
  pet.classList.remove('happy','sad');
  void pet.offsetWidth;
  pet.classList.add('sad');
  setTimeout(() => pet.classList.remove('sad'), 1000);
}

function petTap() {
  const msgs = ['Vamos salvar o planeta! 🌍','Obrigado! ♻️','Recicle sempre! 🌿','Sou seu amigo eco! 🐢','Juntos somos + fortes! 💚','Cuide bem de mim! 🌱','Muito bem!'];
  showBubble(msgs[Math.floor(Math.random() * msgs.length)]);
  petHappy();
  addPoints(1);
  updateUI();
}

function showBubble(text) {
  const b = document.getElementById('bubble');
  b.textContent = text;
  b.classList.remove('show', 'hiding');
  void b.offsetWidth;
  b.classList.add('show');
  clearTimeout(b._hideTimer);
  clearTimeout(b._removeTimer);
  b._hideTimer = setTimeout(() => b.classList.add('hiding'), 4000);
  b._removeTimer = setTimeout(() => b.classList.remove('show', 'hiding'), 4600);
}

function showPtsPopup(text) {
  const el = document.getElementById('ptsPopup');
  el.textContent = text;
  el.classList.remove('show');
  void el.offsetWidth;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 1200);
}

function levelUp() {
  const stage = getPetStage();
  showBubble(`Nível ${state.level}! ${stage.emoji}`);
  celebrate();
}

function celebrate() {
  const emojis = ['🌿','♻️','🌍','💚','⭐','✨','🎉','🌱'];
  for (let i = 0; i < 12; i++) {
    setTimeout(() => {
      const el = document.createElement('div');
      el.className = 'confetti';
      el.textContent = emojis[Math.floor(Math.random() * emojis.length)];
      el.style.left = Math.random() * 100 + 'vw';
      el.style.top = '-30px';
      el.style.animation = `fall ${1 + Math.random()}s ease-in forwards`;
      document.body.appendChild(el);
      setTimeout(() => el.remove(), 2000);
    }, i * 100);
  }
}

// Add fall animation
const style = document.createElement('style');
style.textContent = `@keyframes fall { to { transform: translateY(110vh) rotate(${Math.random()*360}deg); opacity:0; } }`;
document.head.appendChild(style);

function closeModal(id) {
  document.getElementById(id).classList.remove('open');
}

// Close on overlay click
document.querySelectorAll('.modal-overlay').forEach(overlay => {
  overlay.addEventListener('click', function(e) {
    if (e.target === this) this.classList.remove('open');
  });
});

// ==================== INIT ====================
updateUI();
setTimeout(() => showBubble('Olá! Cuide do planeta! 🌍'), 1500);

// Mood decay
setInterval(() => {
  if (document.querySelectorAll('.modal-overlay.open').length === 0) {
    addHP(-1);
    updateUI();
  }
}, 30000);

// ==================== ONBOARDING ====================
let selectedPetPath = 0;

function goStep(n) {
  // Validate step 1
  if (n === 2) {
    const val = document.getElementById('petNameInput').value.trim();
    if (!val) {
      document.getElementById('petNameInput').focus();
      document.getElementById('petNameInput').style.borderColor = 'var(--red)';
      setTimeout(() => document.getElementById('petNameInput').style.borderColor = '', 1000);
      return;
    }
    state.petName = val;
    document.getElementById('previewName').textContent = '✦ ' + val + ' ✦';
    renderPetPickGrid('petPickGrid', true);
  }

  // Update dots
  for (let i = 0; i < 3; i++) {
    const d = document.getElementById('dot' + i);
    d.className = 'step-dot' + (i < n ? ' done' : i === n ? ' active' : '');
  }

  document.querySelectorAll('.onboard-step').forEach((s, i) => {
    s.classList.toggle('active', i === n);
  });
}

function onNameType(val) {
  document.getElementById('nameCount').textContent = val.length;
  document.getElementById('previewPetEmoji').textContent =
    val.length > 0 ? PET_PATHS[selectedPetPath].stages[0] : '🥚';
}

function renderPetPickGrid(containerId, isOnboard) {
  const grid = document.getElementById(containerId);
  grid.innerHTML = '';
  PET_PATHS.forEach((p, i) => {
    const sel = i === selectedPetPath;
    const div = document.createElement('div');
    div.className = 'pet-pick-option' + (sel ? ' selected' : '');
    div.innerHTML = `<span class="pet-pick-emoji">${p.icon}</span><div class="pet-pick-name">${p.name}</div>`;
    div.onclick = () => {
      selectedPetPath = i;
      state.petPath = i;
      document.querySelectorAll(`#${containerId} .pet-pick-option`).forEach((el, j) => {
        el.classList.toggle('selected', j === i);
      });
      if (isOnboard) {
        document.getElementById('previewName').textContent = '✦ ' + (state.petName || 'EcoTama') + ' ✦';
        document.getElementById('previewPetEmoji').textContent = p.stages[0];
      }
      updateUI();
    };
    grid.appendChild(div);
  });
}

function renderHabitatGrid() {
  const grid = document.getElementById('habitatGrid');
  grid.innerHTML = '';
  HABITATS.forEach((h, i) => {
    const sel = i === state.habitatTheme;
    const div = document.createElement('div');
    div.className = 'habitat-option' + (sel ? ' selected' : '');
    div.innerHTML = `
      <div class="habitat-preview" style="background:${h.sky}"></div>
      <div class="habitat-label">${h.label} ${h.name}</div>`;
    div.onclick = () => {
      state.habitatTheme = i;
      document.querySelectorAll('#habitatGrid .habitat-option').forEach((el, j) => {
        el.classList.toggle('selected', j === i);
      });
      applyHabitat();
    };
    grid.appendChild(div);
  });
}

function renderColorGrid() {
  const grid = document.getElementById('colorGrid');
  grid.innerHTML = '';
  ACCENT_COLORS.forEach((c, i) => {
    const sel = c === state.accentColor;
    const div = document.createElement('div');
    div.className = 'color-swatch' + (sel ? ' selected' : '');
    div.style.background = c;
    div.title = c;
    div.onclick = () => {
      state.accentColor = c;
      document.querySelectorAll('#colorGrid .color-swatch').forEach((el, j) => {
        el.classList.toggle('selected', j === i);
      });
      document.documentElement.style.setProperty('--green-light', c);
    };
    grid.appendChild(div);
  });
}

function applyHabitat() {
  const h = HABITATS[state.habitatTheme];
  const sky = document.querySelector('.sky-layer');
  const ground = document.querySelector('.ground-layer');
  if (sky) sky.style.background = h.sky;
  if (ground) ground.style.background = h.ground;
}

function applyRename() {
  const val = document.getElementById('renameInput').value.trim();
  if (!val) return;
  state.petName = val;
  document.getElementById('renameInput').value = '';
  updateUI();
  showBubble(`Oi, me chamo ${val}! 💚`);
  petHappy();
}

function openModal(id) {
  if (id === 'feedModal') renderFeed();
  if (id === 'customModal') {
    renderPetPickGrid('customPetGrid', false);
    renderHabitatGrid();
    renderColorGrid();
    document.getElementById('renameInput').value = state.petName;
  }
  document.getElementById(id).classList.add('open');
}

function startGame() {
  const nameVal = document.getElementById('petNameInput').value.trim();
  if (nameVal) state.petName = nameVal;
  state.petPath = selectedPetPath;
  updateUI();
  const screen = document.getElementById('startScreen');
  screen.classList.add('hide');
  setTimeout(() => showBubble(`Oi, sou ${state.petName}! 🌍`), 600);
}

// Init pet pick on step 0
renderPetPickGrid('petPickGrid', true);

